
(function(){
  const PHONE = "21628296239";
  const langMap = { fr:"FR", nl:"NL", en:"EN", it:"IT", de:"DE", ar:"AR" };
  const htmlLang = (document.documentElement.lang || "fr").toLowerCase();
  const hash = (location.hash||'').toLowerCase();
  const lang = ['ar','nl','en','it','de','fr'].find(l => htmlLang.startsWith(l) || hash.includes('#'+l)) || 'fr';
  const label = langMap[lang] || "FR";

  function guessServiceFromPath(){
    const p = location.pathname.toLowerCase();
    if(p.includes('rhinoplast')) return 'Rhinoplastie';
    if(p.includes('lipo')) return 'Liposuccion';
    if(p.includes('bbl')) return 'BBL Soft';
    if(p.includes('plasma')) return 'J‑Plasma';
    if(p.includes('smile')||p.includes('facette')) return 'Hollywood Smile';
    if(p.includes('greffe')||p.includes('hair')||p.includes('fue')||p.includes('dhi')) return 'Greffe capillaire';
    return 'Consultation';
  }

  function getService(el){
    if(el && el.getAttribute && el.getAttribute('data-service')) return el.getAttribute('data-service');
    if(window.currentService) return String(window.currentService);
    return guessServiceFromPath();
  }

  function msg(el){
    const svc = getService(el);
    const lines = [
      (lang==='ar' ? 'مرحبا!' : 'Bonjour !'),
      'Page: ' + location.pathname,
      'Service: ' + svc,
      'Langue: ' + label
    ];
    return encodeURIComponent(lines.join('\n'));
  }

  function linkFor(el){
    return 'https://wa.me/' + PHONE + '?text=' + msg(el);
  }

  function enhanceAll(){
    const set = new Set([
      ...document.querySelectorAll("a[href*='wa.me'], a[href*='whatsapp']"),
      ...document.querySelectorAll('a[data-service], a[data-wa]')
    ]);
    set.forEach(a=>{
      a.href = linkFor(a);
      if(!a.target) a.target = '_blank';
      if(!a.rel) a.rel = 'noopener';
    });
  }

  function ensureFloat(){
    if(document.getElementById('wa-float')) return;
    const a = document.createElement('a');
    a.id = 'wa-float';
    a.setAttribute('aria-label','WhatsApp');
    a.setAttribute('title', (lang==='ar' ? 'محادثة على واتساب' : 'Discuter sur WhatsApp'));
    a.href = linkFor(a);
    a.target = '_blank';
    a.rel = 'noopener';
    a.innerHTML = '<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M19.11 17.13c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.95 1.17-.17.2-.35.22-.65.07-.3-.15-1.28-.47-2.45-1.5-.9-.8-1.5-1.8-1.68-2.1-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.5-.17 0-.37-.02-.57-.02-.2 0-.52.07-.8.37-.27.3-1.05 1.02-1.05 2.48 0 1.47 1.07 2.9 1.22 3.1.15.2 2.12 3.24 5.13 4.54.72.31 1.28.49 1.72.63.72.23 1.38.2 1.9.12.58-.09 1.76-.72 2.01-1.42.25-.7.25-1.3.17-1.42-.07-.12-.27-.2-.57-.35z"/></svg>';
    document.body.appendChild(a);
  }

  document.addEventListener('DOMContentLoaded', function(){
    enhanceAll();
    ensureFloat();
    document.body.addEventListener('click', function(e){
      const a = e.target.closest('#wa-float, a[data-service], a[data-wa], a[href*="wa.me"], a[href*="whatsapp"])');
      if(!a) return;
      a.href = linkFor(a);
    });
  });
})();